import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { Audio } from 'expo-av';
import colors from '../../constants/colors';

const SplashScreen = ({ navigation }) => {
  useEffect(() => {
    async function playSoundAndNavigate() {
      try {
        const { sound } = await Audio.Sound.createAsync(
          require('../../assets/sounds/mixkit-fast-car-drive-by-1538.mp3')
        );
        await sound.playAsync();
        
        setTimeout(() => {
          navigation.replace('Login');
        }, 3000);
      } catch (error) {
        console.error('Failed to play sound', error);
        navigation.replace('Login');
      }
    }

    playSoundAndNavigate();
  }, []);

  return (
    <View style={styles.container}>
      <Image 
        source={require('../../assets/images/Screenshot (148).png')} 
        style={styles.logo} 
      />
      <Text style={styles.title}>AutoParts Pro</Text>
      <Text style={styles.subtitle}>Premium Car Parts at Your Fingertips</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textSecondary,
  },
});

export default SplashScreen;