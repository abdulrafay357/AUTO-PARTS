import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPartsStart, fetchPartsSuccess, fetchPartsFailure } from '../../redux/slices/partsSlice';
import { categories, parts, featuredParts } from '../../constants/partsData';
import colors from '../../constants/colors';

const HomeScreen = ({ navigation }) => {
  const dispatch = useDispatch();
  const { user } = useSelector(state => state.auth);
  const { featured } = useSelector(state => state.parts);

  useEffect(() => {
    const loadParts = async () => {
      try {
        dispatch(fetchPartsStart());
       
        await new Promise(resolve => setTimeout(resolve, 500));
        dispatch(fetchPartsSuccess({ categories, parts, featured: featuredParts }));
      } catch (error) {
        dispatch(fetchPartsFailure(error.message));
      }
    };

    loadParts();
  }, []);

  const renderFeaturedItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.featuredItem} 
      onPress={() => navigation.navigate('PartDetail', { part: item })}
    >
      <Image 
        source={{ uri: `https://placehold.co/150x150/1a1a1a/fff?text=${item.name.split(' ')[0]}` }} 
        style={styles.featuredImage} 
      />
      <View style={styles.featuredDetails}>
        <Text style={styles.featuredName} numberOfLines={1}>{item.name}</Text>
        <Text style={styles.featuredPrice}>${item.price.toFixed(2)}</Text>
      </View>
    </TouchableOpacity>
  );

  const renderCategoryItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.categoryItem} 
      onPress={() => navigation.navigate('PartsList', { categoryId: item.id })}
    >
      <Ionicons name={item.icon} size={30} color={colors.primary} />
      <Text style={styles.categoryName}>{item.name}</Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Hello, {user?.name || 'Guest'}</Text>
          <Text style={styles.title}>Find the best car parts</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <Ionicons name="person-circle-outline" size={30} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <TouchableOpacity style={styles.searchInput}>
          <Ionicons name="search-outline" size={20} color={colors.textSecondary} />
          <Text style={styles.searchPlaceholder}>Search for parts...</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.filterButton}
          onPress={() => navigation.navigate('Categories')}
        >
          <Ionicons name="filter-outline" size={20} color={colors.onPrimary} />
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Featured Products</Text>
          <TouchableOpacity>
            <Text style={styles.seeAll}>See All</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          data={featured}
          renderItem={renderFeaturedItem}
          keyExtractor={item => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.featuredList}
        />
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Categories</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Categories')}>
            <Text style={styles.seeAll}>See All</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          data={categories.slice(0, 4)}
          renderItem={renderCategoryItem}
          keyExtractor={item => item.id}
          numColumns={2}
          columnWrapperStyle={styles.categoryRow}
          scrollEnabled={false}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  greeting: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginTop: 5,
  },
  searchContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  searchInput: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 12,
    marginRight: 10,
  },
  searchPlaceholder: {
    color: colors.textSecondary,
    marginLeft: 10,
  },
  filterButton: {
    width: 50,
    backgroundColor: colors.primary,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  section: {
    marginBottom: 30,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  seeAll: {
    color: colors.primary,
    fontSize: 14,
  },
  featuredList: {
    paddingRight: 20,
  },
  featuredItem: {
    width: 150,
    marginRight: 15,
  },
  featuredImage: {
    width: 150,
    height: 150,
    borderRadius: 10,
    backgroundColor: colors.surface,
    marginBottom: 10,
  },
  featuredDetails: {
    paddingHorizontal: 5,
  },
  featuredName: {
    color: colors.textPrimary,
    fontSize: 14,
    marginBottom: 5,
  },
  featuredPrice: {
    color: colors.primary,
    fontWeight: 'bold',
    fontSize: 16,
  },
  categoryRow: {
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  categoryItem: {
    width: '48%',
    backgroundColor: colors.surface,
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  categoryName: {
    color: colors.textPrimary,
    marginTop: 10,
    textAlign: 'center',
  },
});

export default HomeScreen;