import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSelector } from 'react-redux';
import colors from '../../constants/colors';

const PartsListScreen = ({ route, navigation }) => {
  const { categoryId } = route.params;
  const { parts, categories } = useSelector(state => state.parts);
  
  const category = categories.find(cat => cat.id === categoryId);
  const categoryParts = parts.filter(part => part.categoryId === categoryId);

  const renderPartItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.partItem} 
      onPress={() => navigation.navigate('PartDetail', { part: item })}
    >
      <Image 
        source={{ uri: `https://placehold.co/150x150/1a1a1a/fff?text=${item.name.split(' ')[0]}` }} 
        style={styles.partImage} 
      />
      <View style={styles.partDetails}>
        <Text style={styles.partName} numberOfLines={2}>{item.name}</Text>
        <Text style={styles.partDescription} numberOfLines={2}>{item.description}</Text>
        <Text style={styles.partPrice}>${item.price.toFixed(2)}</Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>{category?.name || 'Parts'}</Text>
        <View style={{ width: 24 }} />
      </View>

      <FlatList
        data={categoryParts}
        renderItem={renderPartItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  listContent: {
    paddingBottom: 20,
  },
  partItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
  },
  partImage: {
    width: 60,
    height: 60,
    borderRadius: 10,
    marginRight: 15,
  },
  partDetails: {
    flex: 1,
  },
  partName: {
    color: colors.textPrimary,
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  partDescription: {
    color: colors.textSecondary,
    fontSize: 12,
    marginBottom: 5,
  },
  partPrice: {
    color: colors.primary,
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default PartsListScreen;