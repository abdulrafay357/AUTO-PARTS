import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../../redux/slices/cartSlice';
import colors from '../../constants/colors';

const PartDetailScreen = ({ route, navigation }) => {
  const { part } = route.params;
  const dispatch = useDispatch();
  const { items } = useSelector(state => state.cart);

  const handleAddToCart = () => {
    dispatch(addToCart(part));
    navigation.navigate('Cart');
  };

  const isInCart = items.some(item => item.id === part.id);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Cart')}>
          <Ionicons name="cart-outline" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
      </View>

      <Image 
        source={{ uri: `https://placehold.co/300x300/1a1a1a/fff?text=${part.name.split(' ')[0]}` }} 
        style={styles.partImage} 
      />

      <View style={styles.detailsContainer}>
        <Text style={styles.partName}>{part.name}</Text>
        <Text style={styles.partPrice}>${part.price.toFixed(2)}</Text>
        
        <View style={styles.ratingContainer}>
          <Ionicons name="star" size={16} color="#FFD700" />
          <Text style={styles.ratingText}>{part.rating}</Text>
          <Text style={styles.reviewsText}>({part.reviews} reviews)</Text>
          <Text style={styles.inStockText}>
            {part.inStock ? 'In Stock' : 'Out of Stock'}
          </Text>
        </View>

        <Text style={styles.sectionTitle}>Description</Text>
        <Text style={styles.descriptionText}>{part.description}</Text>

        <TouchableOpacity 
          style={[
            styles.addToCartButton,
            isInCart && { backgroundColor: colors.primaryDark }
          ]} 
          onPress={handleAddToCart}
          disabled={!part.inStock}
        >
          <Text style={styles.addToCartButtonText}>
            {isInCart ? 'Already in Cart' : 'Add to Cart'}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
  },
  partImage: {
    width: '100%',
    height: 300,
    resizeMode: 'contain',
    backgroundColor: colors.surface,
  },
  detailsContainer: {
    padding: 20,
  },
  partName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginBottom: 5,
  },
  partPrice: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 15,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  ratingText: {
    color: colors.textPrimary,
    marginLeft: 5,
    marginRight: 10,
  },
  reviewsText: {
    color: colors.textSecondary,
    marginRight: 15,
  },
  inStockText: {
    color: part => part.inStock ? '#4CAF50' : '#F44336',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginBottom: 10,
  },
  descriptionText: {
    color: colors.textSecondary,
    lineHeight: 22,
    marginBottom: 30,
  },
  addToCartButton: {
    backgroundColor: colors.primary,
    borderRadius: 10,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addToCartButtonText: {
    color: colors.onPrimary,
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default PartDetailScreen;