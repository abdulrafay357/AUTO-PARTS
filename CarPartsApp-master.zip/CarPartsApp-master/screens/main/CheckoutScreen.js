import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSelector } from 'react-redux';
import colors from '../../constants/colors';

const CheckoutScreen = ({ navigation }) => {
  const { items, total } = useSelector(state => state.cart);
  const [paymentMethod, setPaymentMethod] = useState('credit');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [nameOnCard, setNameOnCard] = useState('');

  const handlePlaceOrder = () => {
    navigation.navigate('OrderConfirmation');
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>Checkout</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Delivery Address</Text>
        <View style={styles.addressCard}>
          <View style={styles.addressHeader}>
            <Ionicons name="location-outline" size={20} color={colors.primary} />
            <Text style={styles.addressTitle}>Home</Text>
          </View>
          <Text style={styles.addressText}>FUSST</Text>
          <Text style={styles.addressText}>IET 4A</Text>
          <Text style={styles.addressText}>Rawalpindi, PK0004</Text>
          <Text style={styles.addressText}>PAKISTAN</Text>
          <TouchableOpacity style={styles.changeButton}>
            <Text style={styles.changeButtonText}>Change</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Payment Method</Text>
        <View style={styles.paymentMethods}>
          <TouchableOpacity 
            style={[
              styles.paymentMethod, 
              paymentMethod === 'credit' && styles.paymentMethodSelected
            ]}
            onPress={() => setPaymentMethod('credit')}
          >
            <Ionicons 
              name={paymentMethod === 'credit' ? 'radio-button-on' : 'radio-button-off'} 
              size={20} 
              color={paymentMethod === 'credit' ? colors.primary : colors.textSecondary} 
            />
            <Text style={styles.paymentMethodText}>Credit/Debit Card</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[
              styles.paymentMethod, 
              paymentMethod === 'paypal' && styles.paymentMethodSelected
            ]}
            onPress={() => setPaymentMethod('paypal')}
          >
            <Ionicons 
              name={paymentMethod === 'paypal' ? 'radio-button-on' : 'radio-button-off'} 
              size={20} 
              color={paymentMethod === 'paypal' ? colors.primary : colors.textSecondary} 
            />
            <Text style={styles.paymentMethodText}>PayPal</Text>
          </TouchableOpacity>
        </View>

        {paymentMethod === 'credit' && (
          <View style={styles.cardForm}>
            <TextInput
              style={styles.input}
              placeholder="Card Number"
              placeholderTextColor={colors.textSecondary}
              value={cardNumber}
              onChangeText={setCardNumber}
              keyboardType="numeric"
            />
            <View style={styles.row}>
              <TextInput
                style={[styles.input, { flex: 1, marginRight: 10 }]}
                placeholder="MM/YY"
                placeholderTextColor={colors.textSecondary}
                value={expiry}
                onChangeText={setExpiry}
              />
              <TextInput
                style={[styles.input, { flex: 1 }]}
                placeholder="CVV"
                placeholderTextColor={colors.textSecondary}
                value={cvv}
                onChangeText={setCvv}
                keyboardType="numeric"
              />
            </View>
            <TextInput
              style={styles.input}
              placeholder="Name on Card"
              placeholderTextColor={colors.textSecondary}
              value={nameOnCard}
              onChangeText={setNameOnCard}
            />
          </View>
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Order Summary</Text>
        <View style={styles.orderSummary}>
          {items.map(item => (
            <View key={item.id} style={styles.orderItem}>
              <Text style={styles.orderItemName}>{item.name} x{item.quantity}</Text>
              <Text style={styles.orderItemPrice}>${(item.price * item.quantity).toFixed(2)}</Text>
            </View>
          ))}
          <View style={styles.orderTotal}>
            <Text style={styles.orderTotalText}>Total</Text>
            <Text style={styles.orderTotalAmount}>${total.toFixed(2)}</Text>
          </View>
        </View>
      </View>

      <TouchableOpacity 
        style={styles.placeOrderButton} 
        onPress={handlePlaceOrder}
      >
        <Text style={styles.placeOrderButtonText}>Place Order</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginBottom: 15,
  },
  addressCard: {
    backgroundColor: colors.surface,
    borderRadius: 10,
    padding: 15,
  },
  addressHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  addressTitle: {
    color: colors.textPrimary,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  addressText: {
    color: colors.textSecondary,
    marginBottom: 5,
  },
  changeButton: {
    alignSelf: 'flex-end',
    marginTop: 10,
  },
  changeButtonText: {
    color: colors.primary,
  },
  paymentMethods: {
    backgroundColor: colors.surface,
    borderRadius: 10,
    overflow: 'hidden',
  },
  paymentMethod: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  paymentMethodSelected: {
    backgroundColor: `${colors.primary}10`,
  },
  paymentMethodText: {
    color: colors.textPrimary,
    marginLeft: 10,
  },
  cardForm: {
    marginTop: 15,
  },
  input: {
    backgroundColor: colors.surface,
    borderRadius: 10,
    height: 50,
    paddingHorizontal: 15,
    color: colors.textPrimary,
    marginBottom: 15,
  },
  row: {
    flexDirection: 'row',
  },
  orderSummary: {
    backgroundColor: colors.surface,
    borderRadius: 10,
    padding: 15,
  },
  orderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  orderItemName: {
    color: colors.textSecondary,
  },
  orderItemPrice: {
    color: colors.textPrimary,
  },
  orderTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  orderTotalText: {
    color: colors.textPrimary,
    fontWeight: 'bold',
  },
  orderTotalAmount: {
    color: colors.primary,
    fontWeight: 'bold',
    fontSize: 16,
  },
  placeOrderButton: {
    backgroundColor: colors.primary,
    borderRadius: 10,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
  placeOrderButtonText: {
    color: colors.onPrimary,
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default CheckoutScreen;