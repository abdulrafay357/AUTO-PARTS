import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from '../screens/main/HomeScreen';
import CategoriesScreen from '../screens/main/CategoriesScreen';
import PartsListScreen from '../screens/main/PartsListScreen';
import PartDetailScreen from '../screens/main/PartDetailScreen';
import CartScreen from '../screens/main/CartScreen';
import CheckoutScreen from '../screens/main/CheckoutScreen';
import OrderConfirmationScreen from '../screens/main/OrderConfirmationScreen';
import ProfileScreen from '../screens/main/ProfileScreen';

const Stack = createStackNavigator();

const MainStack = () => {
  return (
    <Stack.Navigator
      initialRouteName="Home"
      screenOptions={{
        headerStyle: {
          backgroundColor: '#1a1a1a',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'AutoParts Pro' }} />
      <Stack.Screen name="Categories" component={CategoriesScreen} options={{ title: 'Categories' }} />
      <Stack.Screen name="PartsList" component={PartsListScreen} options={{ title: 'Parts' }} />
      <Stack.Screen name="PartDetail" component={PartDetailScreen} options={{ title: 'Part Details' }} />
      <Stack.Screen name="Cart" component={CartScreen} options={{ title: 'Your Cart' }} />
      <Stack.Screen name="Checkout" component={CheckoutScreen} options={{ title: 'Checkout' }} />
      <Stack.Screen name="OrderConfirmation" component={OrderConfirmationScreen} options={{ title: 'Order Confirmation', headerLeft: null }} />
      <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: 'Your Profile' }} />
    </Stack.Navigator>
  );
};

export default MainStack;