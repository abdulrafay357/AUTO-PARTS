import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  categories: [],
  parts: [],
  featured: [],
  loading: false,
  error: null,
};

const partsSlice = createSlice({
  name: 'parts',
  initialState,
  reducers: {
    fetchPartsStart: (state) => {
      state.loading = true;
      state.error = null;
    },
    fetchPartsSuccess: (state, action) => {
      state.categories = action.payload.categories;
      state.parts = action.payload.parts;
      state.featured = action.payload.featured;
      state.loading = false;
    },
    fetchPartsFailure: (state, action) => {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const { fetchPartsStart, fetchPartsSuccess, fetchPartsFailure } = partsSlice.actions;

export default partsSlice.reducer;