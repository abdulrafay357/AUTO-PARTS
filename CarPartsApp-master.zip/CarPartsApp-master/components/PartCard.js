import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../constants/colors';

const PartCard = ({ part, onPress }) => (
  <TouchableOpacity onPress={onPress} style={styles.card}>
    <Image 
      source={{ uri: part.image || 'https://placehold.co/100x100/1a1a1a/fff?text=Part' }} 
      style={styles.image} 
      resizeMode="contain"
    />
    <View style={styles.details}>
      <Text style={styles.name} numberOfLines={1}>{part.name}</Text>
      <Text style={styles.price}>${part.price?.toFixed(2) || '0.00'}</Text>
      <Text style={styles.category}>{part.category || 'Car Part'}</Text>
    </View>
    <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
  },
  image: {
    width: 60,
    height: 60,
    marginRight: 15,
  },
  details: {
    flex: 1,
  },
  name: {
    color: colors.textPrimary,
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  price: {
    color: colors.primary,
    fontWeight: 'bold',
    fontSize: 16,
  },
  category: {
    color: colors.textSecondary,
    fontSize: 12,
  },
});

export default PartCard;