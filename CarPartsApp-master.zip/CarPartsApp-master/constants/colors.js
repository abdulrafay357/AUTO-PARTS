export default {
  primary: '#E63946', // Vibrant red
  primaryDark: '#B71C1C', // Darker red
  secondary: '#1A1A1A', // Dark background
  background: '#121212', // Slightly darker than secondary
  surface: '#242424', // Cards, buttons
  error: '#F44336',
  success: '#4CAF50',
  warning: '#FFC107',
  textPrimary: '#FFFFFF',
  textSecondary: '#BDBDBD',
  textDisabled: '#757575',
  border: '#333333',
  divider: '#2D2D2D',
  highlight: '#FF5252', // For interactive elements
};